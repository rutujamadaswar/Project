package com.project1.categoryProduct_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CategoryProductApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
